# Script: instalar_office.ps1
# Objetivo: Baixar, descompactar e instalar o Office 365 com base no arquivo office64.xml

# Define variáveis
$zipUrl = "https://github.com/dpinheirolimacouto/prodiet/raw/refs/heads/main/OfficeInstallProdiet.zip"
$downloadPath = "C:\OfficeInstallProdiet.zip"
$extractRoot = "C:\OfficeInstallProdiet"

# Baixa o arquivo ZIP
Write-Output "Baixando pacote do Office 365..."
Invoke-WebRequest -Uri $zipUrl -OutFile $downloadPath -UseBasicParsing

# Descompacta o arquivo
Write-Output "Descompactando arquivos em $extractRoot..."
Expand-Archive -Path $downloadPath -DestinationPath $extractRoot -Force

# Diagnóstico: listar todos os arquivos extraídos
Write-Output "Arquivos extraídos:"
Get-ChildItem -Path $extractRoot -Recurse

# Tenta localizar setup.exe e office64.xml em qualquer subpasta
$setupPath = Get-ChildItem -Path $extractRoot -Recurse -Filter "setup.exe" | Select-Object -First 1
$xmlPath = Get-ChildItem -Path $extractRoot -Recurse -Filter "office64.xml" | Select-Object -First 1

if ($setupPath -and $xmlPath) {
    Write-Output "setup.exe encontrado em: $($setupPath.FullName)"
    Write-Output "office64.xml encontrado em: $($xmlPath.FullName)"
    
    # Define diretório de trabalho como a pasta onde está o setup.exe
    $workingDir = Split-Path $setupPath.FullName

    Write-Output "Iniciando instalação do Office 365..."
    Start-Process -FilePath $setupPath.FullName -ArgumentList "/configure office64.xml" -WorkingDirectory $workingDir -Wait
} else {
    Write-Output "ERRO: setup.exe ou office64.xml não encontrados."
}

# Limpeza opcional
Remove-Item -Path $downloadPath -Force
